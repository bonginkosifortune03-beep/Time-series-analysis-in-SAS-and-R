data blue_noise;
n=100;
phi=-0.6;
a_t=0;
seed=1234567;
*then a do loop for the simulation;
do t=1 to 1000;
 at_1=phi*a_t + sqrt(1 - phi**2) * rannor(seed);

 output;

 a_t = at_1; *resetting the values simulated;
 end;
 run;


goptions reset all i=join;
symbol1 color=black;
title 'Simulation of Gaussaian Blue Noise Process';
proc gplot data=blue_noise;
plot at_1*t/ vref=-15 -10 0 10 15;
run;

*plotting the correlogram;
proc arima data=blue_noise;
identify var=at_1 nlag=12;
run;

/*Comment autocorrelatio:

We see that autocorrelations are closer to zero which shows that we have randommness and weak relation between the
variable observation and the is weak memory ;
