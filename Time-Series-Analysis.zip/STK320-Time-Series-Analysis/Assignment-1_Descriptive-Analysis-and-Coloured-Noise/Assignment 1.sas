*Question 1 Wolfer Dataset;

proc import datafile="wolfer.csv"
out=Wolfer
dbms=csv
replace;
run;

*Question 1a- Time plot for Wolfer Sunspot;
proc sgplot data=Wolfer;
scatter Y=Sunspots x=Year;
series Y=Sunspots x=Year;
title 'Time plot for Annual sunspot numbers from 1750 to 1900';
xaxis label='Year';
yaxis label='Sunspot';
run;

*Number C-Correlogram;
proc arima data=Wolfer
plots(only)=series(acf);
identify var=Sunspots nlag=36;
run;

*Number D;
/*
This shows a irregularity varaition
This may also show a seasonality;
*/



*Question 1 katsedam Dataset;
*Monthly Rainfall;
proc import datafile="katsedam.csv"
out=katsedam
dbms=csv
replace;
getnames=yes;
run;

*we then need to create new data;
data katsedam2;
    set work.katsedam;
    /* Create SAS date using INTNX */
    Date = input(cats('01', Month, Year), date9.); *so this is used to put the year and months colounm together;
    format Date monyy7.;
	keep Rainfall date;
run;


*Time plot for Monthly rainfall in Katse;
proc sgplot data=katsedam2;
    series x=Date y=Rainfall / markers;
    title 'Time plot for monthly rainfall in Katse dam from January 1940 to December 1999';
    xaxis label='Date';
    yaxis label='Rainfall (mm)';
run;

*Number C-Correlogram;
proc arima data=katsedam2
plots(only)=series(acf);
identify var=Rainfall nlag=36; *36 is the number of lags;
run;

*Number D;
/*
This shows a irregularity varaition
This may also show a seasonality ;
*/
