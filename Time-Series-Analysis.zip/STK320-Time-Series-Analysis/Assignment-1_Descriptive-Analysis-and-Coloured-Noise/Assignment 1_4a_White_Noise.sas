data white_noise;
n=100;
phi=0;
a_t=0;
seed=1234567;
*then a do loop for the simulation;
do t=1 to 1000;
 at_1=phi*a_t + sqrt(1 - phi**2) * rannor(seed);

 output;

 a_t = at_1; *resetting the values simulated;
 end;
 run;

/*then plot the time plot;
proc sgplot data=white_noise;
scatter X=t Y=a;
series X=t  Y=a;
run;
*/

goptions reset all i=join;
symbol1 color=black;
title 'Simulation Gaussaian White Noise Process';
proc gplot data=white_noise;
 plot at_1*t/ vref=-15 -10 0 10 15;
 run;

*plotting the correlogram;
proc arima data=white_noise plots(only)=series(acf pacf);
identify var=at_1 nlag=12;
run;

proc print data=white_noise;
var n t at;
run;

*Commement of the autocorrelation structure;
/*We see that the autocorrelation are closer to zero meaning that we the variable are weak 
 this sohw that this has memoery */
