proc import datafile="rand-dollar.txt"
out=Rand
dbms=dlm
replace;
getnames=no; *since we are not satified with the naming conversion;
run;

*then we need to rename and create new variable;
data rand_raw; set rand;
rename var1=Rate;
t=_n_;
run;


*Number a;
data new_rand_raw; set rand_raw;
yt=log(Rate);     *log of t;
yt_lag=lag(yt);
xt=yt_lag-yt;   *change in Y;
wt=100*xt;      *approximation of t;
run;

proc print data=new_rand_raw (obs=6);
run;

*Number b;
*drawing the time plot;
proc sgplot data=new_rand_raw;
*scatter X=t Y=xt;
series X=t Y=xt;
title 'Time plot for percentage change in daily Rand-US exchange rate';
xaxis label='Time';
yaxis label='Percentage change (Rand-US)';
run;

*another way of plotting;
goptions reset=all;
axis1 label=(angle=90 'Time') order= 0 to 500 by 100;
axis2 label=('Percentage change (Rand-US)' minor=(number=6);
symbol1 color=black i=join ;
title 'Time plot for percentage change in daily Rand-US exchange rate';
proc gplot data=new_rand_raw;
plot xt*t;
run;

*Question 2c;
*The effect of sharp depreciation will cause an increase in volitility of the 
exchange rate of the Rand-US$ exchange rate

This is because a sharp depreciation often leads to high volatility clustering
;

*Question 2d;
*Since we have percentages we need to get the maximum increase and maximum decrease;
proc means data=new_rand_raw max min;
var wt;
run;

*Maximum percentage increase=4.5930480
Maximum percentage decrease=-5.5208824;


