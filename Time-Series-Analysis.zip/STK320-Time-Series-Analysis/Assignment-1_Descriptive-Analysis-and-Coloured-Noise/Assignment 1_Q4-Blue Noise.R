#This is a white noise simulation
n <- 1000   #this is samle size
set.seed(7)
a_1 <- 0    #this is the initial a value
p <- -0.6

#initializing the vector to solve values
at_values <- numeric(n)

#Generate red noise using a standard normal distribution
for(t in 1:n){
  at <- p * a_1 + sqrt(1 - p^2) * rnorm(1)
  at_values[t] <- at
}

#converting to data frame
blue_noise <-data.frame(t = 1:n, at = at_values)
head(blue_noise)


library(ggplot2)

ggplot(data = blue_noise,
       aes(x = t , y = at))+
  geom_point(color='black')+
  geom_line(color='black')+
  ggtitle("Blue noise Gausian Simulation")+
  xlab('Time')+
  ylab('Simulation')

#Now for doing the correlogram
acf(blue_noise$at,
    lag.max = 12,
    main='Correlogrma (ACF) of Gausian Blue noise',
    col='red')


#Comments of the autocorrelation structure;
#We see that the autocorrelation are closer to zero meaning that
#we the variable are weekly 
#correlated and show irregularity and randommness
#  
