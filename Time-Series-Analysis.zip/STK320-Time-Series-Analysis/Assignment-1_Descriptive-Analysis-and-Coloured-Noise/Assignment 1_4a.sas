
proc iml;
n=1000;
it=1;
dim=n||it;
call randseed(7,1); wt=randfun(dim,'normal',0,1);
p=0;
a=J(n,it,.);
a[1]=0;
do t=2 to n;
a[t]=p*a[t]+sqrt(1-p**2)*wt[t];
end;
run; 

*create an index for time;
time=(1:n)`;     *print time;
result=time||a;


create white_noise from result[colname={"t" "a"}];
append from result;
close white_noise;

/**then if we draw time plot;
proc sgplot data=white_noise;
scatter X=t Y=a;
series X=t Y=a;
run;
*/
goptions reset all i=join;
symbol1 color=black;
title 'Simulation Gaussaian White Noise Process';
proc gplot data=white_noise;
 plot a*t/ vref=-15 -10 0 10 15;
 run;

*checking if the means and variance are zero and constant;
proc means data=white_noise;
var a;
run;

*Then we do the correlogram;
proc arima data=white_noise;
identify var=a nlag=12;
run;


proc print data=white_noise;
var t a;
run;


/*
data white_noise;
n=1000;
seed=15;
*var_at=1;
*it=1;        *number of iterations;
a=0;
p=0;
output;
*then a do loop for the simulation;
do t=1 to 1000;
 a=p*a+sqrt(1-p**2)*rannor(seed);
 output;
 end;
 run;

proc print data=white_noise;
var n t a;
run;

*then plot the time plot;
proc sgplot data=white_noise;
scatter X=t Y=a;
series X=t  Y=a;
run;

*plotting the correlogram;
proc arima data=white_noise;
identify var=a nlag=12;
run;
*/
