#this is question 3;

#Reading Textfile
file_path<-"rand-dollar.txt"  # lecture example file (not included); place it in this folder
Rand<- read.table(file_path,
                  header=FALSE,
                  sep="",
                  strip.white=TRUE)
#Number a

#We then rename coloum to Rate;
colnames(Rand)[1]<-"Rate"
#then create new table with number of observation
Rand$t<-1:nrow(Rand)
#head(Rand)

#we need this library for lagging;
library(dplyr)

#Then we do data tranformation
new_rand<-Rand
new_rand$yt<- log(new_rand$Rate)
new_rand$yt_lag<- dplyr::lag(new_rand$yt, default = NA)
new_rand$xt<-new_rand$yt_lag-new_rand$yt
new_rand$wt<- 100*new_rand$xt
#printing the first 6 rows
head(new_rand)

#Number 
library(ggplot2)
ggplot(data=new_rand,
       aes(x=t, y=xt))+
       geom_point(color='blue')+
       geom_line(color='blue')+
       ggtitle('Time plot for percentage change in daily Rand-US exchange rate')+
       xlab('Time')+
       ylab('Percentage change (Rand-US)')


