#For the Wolfer dataset;
Wolfer<-read.csv("wolfer.csv",
                header=TRUE) #you need to change the backlash to forward slash;

#For plotting time plot we need to install a package
library(ggplot2)

#plotting a graph;
ggplot(data=Wolfer,
      aes(x = Year, y=Sunspots))+
      geom_point(color="red")+
      geom_line(color="Blue")+
      ggtitle("Time plot for Annual sunsplot numbet from 1750 to 1900")+
      xlab("Year")+
      ylab("Sunspot")

#Plotting the correlogram off 36 lags;
acf(Wolfer$Sunspots,
    lag.max = 36,
    main="Correlogrma (ACF) of Sungspots",
    col='red')



#For the Katsedam dataset;
katsedam<-read.csv("katsedam.csv",
                   header=TRUE)

#convert months in character to months in numeric;
katsedam$Month<- match(katsedam$Month,month.abb)


# Combine Year and Month into a Date column
katsedam$Date <- as.Date(paste(katsedam$Year, katsedam$Month, "01", sep = "-"), format = "%Y-%m-%d")

#Keep only the Date and Rainfall columns
katsedam2 <- katsedam[, c("Date", "Rainfall")]

#View the cleaned data
head(katsedam2)

#Then we then plot a ggplot
ggplot(data=katsedam2,
       aes(x=Date, y=Rainfall))+
       geom_point(color="blue")+
       geom_line(color="blue")+
       ggtitle("Time plot for monthly rainfall in Katse dam from January 1940 to December 1999")+
       xlab("Date")+
       ylab("Rainfall")

#also we need to do the correlogram;
acf(katsedam2$Rainfall,
    lag.max =36,
    main="Correlogrma (ACF) of Rainfall",
    col='Black')


  