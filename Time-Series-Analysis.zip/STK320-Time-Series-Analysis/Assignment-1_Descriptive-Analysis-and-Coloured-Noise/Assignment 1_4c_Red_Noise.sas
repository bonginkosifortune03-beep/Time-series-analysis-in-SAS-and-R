data red_noise;
n=100;
phi=0.6;
a_t=0;
seed=1234567;
*then a do loop for the simulation;
do t=1 to 1000;
 at_1=phi*a_t + sqrt(1 - phi**2) * rannor(seed);

 output;

 a_t = at_1; *resetting the values simulated;
 end;
 run;
 /*
*then do time slot;
 proc sgplot data=red_noise;
 *scatter X=t Y=a;
 series X=t Y=a;
 run;
 */
 goptions reset all  i=join;
 symbol1 color=red;
 title 'Simulation of Gaussain Red Noise';
 proc gplot data=Red_Noise;
 plot at_1*t/vref= -15 -10 0 10 15;
 run;


 proc arima data=red_noise;
 identify var=at_1 nlag=12;
 run;

 /*So the autocorrelation are close to zero;
 it memory and it showe an exponetila decay 
 as the number of lags increase then autocorrelation decrease;
 it showes weak relation between the variables
 */
