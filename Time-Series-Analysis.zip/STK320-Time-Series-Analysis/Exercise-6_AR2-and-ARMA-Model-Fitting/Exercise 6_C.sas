*so now we need to fit an ARMA(1,1) model;
data ar2;
n=100;
seed=7;
theta0=10;
phi1=0.2;
phi2=0.7;
mu=theta0/(1-phi1-phi2);
var_at=4;
zt_2=mu;
zt_1=mu;
do t = -49 to n;
at=sqrt(var_at)*rannor(seed);
zt=theta0+phi1*zt_1+phi2*zt_2+at;
if t > 0 then output;
zt_2=zt_1;
zt_1=zt;
end;
run;

*then do proc arima to get the parameter estimates using ML method;
goptions reset=all;
title 'AR(2) Series Simulated- ARMA(1,1) model fitted';
proc arima data=ar2 out=fit_arma plots(only)=residual(acf pacf);
identify var=zt nlag=6 noprint;
estimate p=1 q=1 method=ml;
forecast lead=0;
run;

data res_arma; set fit_arma;
t=_n_;
run;
*then we need to get the correlation between the actual values with the
the predicted values;
proc corr data=res_arma;
 var zt forecast;
 run;

 *then we not need to plot the time plots;
goptions reset=all i=join;
axis1 label=(angle=90 'Observed and Predicted values')
order =90 to 110 by 5;
legend1 label= ('Series:')
value=('Observed Values' 'Predicted Values');
symbol1 color=black line=33;
symbol2 coloe=brown line=1;
title1 'ARMA(1,1) Model Fitted';
title2 'Time Plot of Observed and Predicted Valeus';
proc gplot data=res_arma;
plot (zt forecast)*t / overlay legend=legend1 vaxis=axis1;
run;


*then we need to plot the residuals with series;
goptions reset=all i=needle;
axis1 label=(angle=90 'Residuals') order = -10 to 10 by 1;
symbol1 color=brown;
title1 'AR(2) Model Fitted';
title2 'Plot of Residual Series';
proc gplot data=res_arma;
plot residual*t / vaxis=axis1 vref=0;
run;

*we then need to plots residuals against predicted values;
proc gplot data=res_arma;
plot residual*forecast / vaxis=axis1 haxis=axis2;
run;

*then we need to test for normality;
goptions reset=all;
title 'ARMA(1,1) Model Fitted';
title 'Testing for Normality';
proc univariate data=res_arma noprint;
 histogram residual / normal(mu=est sigma=est color=purple);
 probplot residual / normal (mu=est sigma=est color=purple) square;
run;
