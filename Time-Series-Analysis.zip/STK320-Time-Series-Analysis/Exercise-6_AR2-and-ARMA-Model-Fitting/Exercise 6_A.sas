*we need to simulate the given time series equation on the question;
data ar2;
n=100;
seed=7;
theta0=10;
phi1=0.2;
phi2=0.7;
mu=theta0/(1-phi1-phi2);
var_at=4;
zt_2=mu;
zt_1=mu;
do t = -49 to n;
at=sqrt(var_at)*rannor(seed);
zt=theta0+phi1*zt_1+phi2*zt_2+at;
if t > 0 then output;
zt_2=zt_1;
zt_1=zt;
end;
run;

*Question 2a
we need to fit an AR(1) model using the maximus likelihood estimate;
goptions reset=all;
title1 'AR(2) Series Simulated - AR(1) Model Fitted';
proc arima data=ar2 out=fit_ar1 plots(only)=residuals(acf pacf);
identify var=zt nlag=6 noprint;
estimate p=1 method=ml;
forecast lead=0;
run;

*then we create a new dataset and create number of observation;
data res_ar1; set fit_ar1;
t=_n_;
run;


*then we create the correlation between what we have observed and the predicted;
proc corr data=res_ar1;
 var zt forecast;
run;

*then we need to plot the forecast and the observed on the same plot;
goptions reset=all i=join;
axis1 label=(angle=90 'Observed and Predicted Values')
order = 90 to 110 by 5;
legend1 label=('Series:')
value=('Observed Values' 'Predicted Values');
symbol1 color=black line=33;
symbol2 color=brown line=1;
title1 'AR(1) Model Fitted';
title2 'Time Plot of Observed and Predicted Values';

proc gplot data=res_ar1;
plot (zt forecast)*t /overlay legend=legend1 vaxis=axis1;
run;


*then we need to plot the residuals with series;
goptions reset=all i=needle;
axis1 label=(angle=90 'Residuals') order = -10 to 10 by 1;
symbol1 color=brown;
title1 'AR(1) Model Fitted';
title2 'Plot of Residual Series';

proc gplot data=res_ar1;
 plot residual*t/ vaxis=axis1 vref=0;
run;

*then plot the residuals agaist the forecast;
proc gplot data=res_ar1;
 plot residual*forecast/ vaxis=axis1 haxis=axis2;
 run;


 *then we need to test for normality using the histogram, qqplot ;
 proc univariate data=res_ar1 noprint;
  histogram residual/ normal(mu=est sigma=est color=brown);
  probplot residual / normal (mu=est sigma=est color=brown) square;
run;

*this is simple way;
proc univariate data=res_ar1 normal plots;
var residual;
run;
