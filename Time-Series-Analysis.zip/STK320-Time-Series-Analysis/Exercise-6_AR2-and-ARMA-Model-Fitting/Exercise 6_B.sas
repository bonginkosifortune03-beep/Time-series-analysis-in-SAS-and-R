*so now we are doing for model AR(2);
*we need to simulate the given time series equation on the question;
data ar2;
n=100;
seed=7;
theta0=10;
phi1=0.2;
phi2=0.7;
mu=theta0/(1-phi1-phi2);
var_at=4;
zt_2=mu;
zt_1=mu;
do t = -49 to n;
at=sqrt(var_at)*rannor(seed);
zt=theta0+phi1*zt_1+phi2*zt_2+at;
if t > 0 then output;
zt_2=zt_1;
zt_1=zt;
end;
run;

goptions reset=all;
title1 'AR(2) Series Simulated - AR(2) Model Fitted';
proc arima data=ar2 out=fit_ar1 plots(only)=residuals(acf pacf);
identify var=zt nlag=6 noprint;
estimate p=2 method=ml;
forecast lead=0;
run;

data res_ar2; set fit_ar2;
t=_n_;
run;

*then now w need to do correlation analysis to the coeffiencent of determinations;
proc corr data=res_ar2;
var zt forecast;
run;

*then now the time plots for the residuals. predicted and them against each
other;
goptions reset=all i=join;
axis1 label=(angle=90 'Observed and Predicted values')
order =90 to 110 by 5;
legend1 label= ('Series:')
value=('Observed Values' 'Predicted Values');
symbol1 color=black line=33;
symbol2 coloe=brown line=1;
title1 'AR(1) Model Fitted';
title2 'Time Plot of Observed and Predicted Valeus';
proc gplot data=res_ar2;
plot (zt forecast)*t /overlay legend=legend1 vaxis=axis1;
run;


*then we need to plot the residuals with series;
goptions reset=all i=needle;
axis1 label=(angle=90 'Residuals') order = -10 to 10 by 1;
symbol1 color=brown;
title1 'AR(2) Model Fitted';
title2 'Plot of Residual Series';
proc gplot data=res_ar2;
 plot residual*t / vaxis=axis1 vref=0;
 run;

 *then we need to plot residuals against predicted values;
 proc gplot data=res_ar2;
  plot residual*forecast / vaxis=axis1 haxis=axis2;
  run;

  *then now we need to test for normaliry of the risiduals
   using Histogram QQplot and statistical tests;
  proc univariate data=res_ar2 noprint;
   histogram residual/ normal (mu=est sigma=est color=orange);
   probplot residual / normal (mu=est sigma=est color=orange) square;
run;


*this is simple way;
proc univariate data=res_ar2 normal plots;
var residual;
run;
