*generating a AR(1) model;
data AR_Xt;
n=900;          *number of observations;
seed=13;
theta0=(75/2);  *for this example we worked out the theta0 using formula;
phi=0.5;    
var_at=9;       *the given variance;
mean_xt=70;     *the mean;
xt_1=mean_xt;   *if we set it to zero it will not get close to the thoeretical mean;


do t = -49 to n;
   at=sqrt(var_at)*rannor(seed);
   xt=phi * xt_1 + at;
   zt= mean_xt + xt;             *the correct model;
   zt_uc= mean_xt + at;          *the incorrect model;
   if t > 0 then output;         *only observation greater than 0;
   xt_1= xt;                     *reinitialising;
end;
run;

*Question b;
*we can also use autoreg to get the output;
proc autoreg data=AR_Xt plots=none;
model zt_uc=  / dwprob;*used to get the pvalue;  *we do not need any parameters since we want zt;
output out=autoreg_out
       p=zhat;                        *getting the predicted output;
run;


*plot;
goptions reset=all i=join;
symbol1 color=black;
symbol2 color=red;
proc gplot data=autoreg_out;
plot (zt_uc zhat)*t/overlay;
run;

*Question c;
proc autoreg data=AR_Xt plots=none;
model zt= /  dwprob nlag=1 method=uls;     *we do not need any parameters since we want zt;
output out=autoreg_out2
       p=zhat2;                    *getting the predicted output;
run;
/*
proc reg data=AR_Xt plots=none;
model zt =/ dw;
run;*/

*plot;
proc gplot data=autoreg_out2;
*where t<100;
plot (zt zhat2)*t/overlay;
run;

