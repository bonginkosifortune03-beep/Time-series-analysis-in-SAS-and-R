*Question f;
data MA_1_Yt;
n=1000;
seed=7;
*defining parameters;
theta0=0;
theta=-1;
vt_1=-3 + 6*ranuni(seed);  *this is for uniform innovation (-3,3);
do t = -49 to n;
 vt= -3 + 6*ranuni(seed); *we are using 6 because (b-a) =(3--3)=6;
 yt = theta0 +vt-theta * vt_1;
 if t > 0 then output;
 vt_1= vt;
end;
run;

**Question g;
proc univariate data=MA_1_Yt;
var yt;
run;

proc arima data=MA_1_Yt;
identify var=yt nlag=6;
run;


**Question h;
*plotting the graph;
goptions reset=all i=join;
symbol1 color=black;
symbol2 color=red;
proc gplot data=MA_1_Yt;
where t<100;
plot (yt vt)*t / overlay;
run;

*Question i;
proc univariate data=MA_1_Yt normal plot;
var yt vt;
run;
