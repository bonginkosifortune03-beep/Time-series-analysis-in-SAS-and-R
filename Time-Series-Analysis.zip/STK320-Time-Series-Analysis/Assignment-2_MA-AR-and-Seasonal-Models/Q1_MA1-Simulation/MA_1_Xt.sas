*i think we need to similate the MA(1) process;
*Question f;
data MA_1_Xt;
n=1000;
seed=7;
theta0=0; *theta0 is zero;
theta=-1; *theta one is 1 but we use it as negative;
var_at=3; 
ut_1=sqrt(var_at)*rannor(seed); * lagged white noise term;
 
do t = -49 to n;
ut=sqrt(var_at)*rannor(seed);
xt=theta0 + ut - theta*ut_1;
if t > 0 then output;     *printing only observations with time greater than 0;
ut_1=ut;                  *this reinitialise;
end;
run;


**Question g;
proc univariate data=MA_1_Xt;
var xt;
run;

proc arima data=MA_1_Xt;
identify var=xt nlag=6;
run;


**Question h;
*plotting the graph;
goptions reset=all i=join;
symbol1 color=black;
symbol2 color=red;
proc gplot data=MA_1_Xt;
where t<100;                *this is for plotting the first 100;
plot (xt ut)*t /overlay ;   *this printing both xt and au;
run;

*Question i;
proc univariate data=MA_1_Xt normal plot;
var xt ut;
run;

