*Question 1 katsedam Dataset;
*Monthly Rainfall;
proc import datafile="katsedam.csv"
out=katsedam
dbms=csv
replace;
getnames=yes;
run;


*we then need to create new data;
data katsedam2;
    set work.katsedam;
    /* Create SAS date using INTNX */
    Date = input(cats('01', Month, Year), date9.); *so this is used to put the year and months colounm together;
    format Date monyy7.;
	keep Rainfall date;
run;

*we need to fit this model
Zt=theta0+alpha*cos((pi/6)*t +s*sin((pi/6)*t)+at;
data K3; set katsedam2;
*seed=7;
*theta0=mean(Rainfall);          *this give theta0;
*std_at=std(Rainfall);           *this gives the variance;
t=_n_;                          *give the number of observation;
period=12;                      *this is 12 month period;
freq=2*constant('pi')/period;   *this is getting the frequncy;
cos=cos(freq*t);                *cos function;
sin=sin(freq*t);                *sin function;
*at=std_at*rannor(seed);   *getting the white noise process;
run;

proc autoreg data=K3 plots=none;
model Rainfall= cos sin /  method=uls;
output out=Pred
  p=Predicted;
run;

goptions reset=all i=join;
legend1 label=('Rainfall Data') value=('Observed Value' 'Predeicted');
symbol1 color=black;
symbol2 color=red;
proc gplot data=Pred;
 plot (Rainfall Predicted)*t /overlay legend=legend1;
run;



