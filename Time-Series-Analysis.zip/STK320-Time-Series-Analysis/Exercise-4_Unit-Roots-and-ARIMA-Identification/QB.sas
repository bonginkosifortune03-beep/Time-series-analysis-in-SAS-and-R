*This is exercise 4;
proc import datafile="exercise4.csv"
out=Exe4 
dbms=csv
replace;
run;

*we need to get the first difference of the series;
data identify; 
set Exe4; 
dser1=dif(ut); 
dser2=dif(vt); 
dser3=dif(wt); 
dser4=dif(xt); 
dser5=dif(yt); 
dser6=dif(zt); 
run; 

goptions reset=all i=join;
symbol1 color=black;
title 'First Difference of ut';
proc gplot data=identify;
 plot dser1*t;
run;

*plot for the actual seris ut;
goptions reset=all i=join;
symbol1 color=black;
title 'Series ut';
proc gplot data=identify;
 plot ut*t;
run;

*Question a1-ut;
proc arima data=identify plots(only)=series(acf pacf);
 identify var=ut(1) stationarity=(adf=(0,1)); *this is for the first difference;
 identify var=ut stationarity=(adf=(0,1));
run;

*Then we do for serious is vt;
*we first need to plot the difference and the actual series;
goptions reset=all i=join;
symbol1 color=black;
title 'First difference of vt';
proc gplot data=identify;
 plot dser2*t;
run;
*then we also need to plot for the original series;
goptions reset=all i=join;
symbol1 color=black;
title 'Plot for Vt';
proc gplot data=identify;
 plot vt*t;
run;

*then we need to run the stationarity test on arima;
proc arima data=identify;
*identify var=dser2 stationarity=(adf=(0,1,2)) we can also use this way; 
identify var=vt(1) stationarity=(adf=(0,1));
identify var=vt stationarity=(adf=(0,1));
run;

*then now we need to do for wt;
*we first need to get the plots of the first differences and original series;
goptions reset=all i=join;
symbol1 color=black;
title 'First difference for the wt';
proc gplot data=identify;
 plot dser3*t;
run;

*then plot the original series;
goptions reset=all i=join;
symbol1 color=black;
title 'Original wt';
proc gplot data=identify;
 plot wt*t;
run;

*then we need to do the statinarity test in proc arima;
proc arima data=identify plots(only)=series(acf pacf);
 identify var=wt(1) stationarity=(adf=(0,1));
 *identify var=dser3 stationarity=(adf=(0,1));
 identify var=wt statinarity=(adf=(0,1));
 run;

 *then for series xt;
goptions reset=all i=join;
symbol1 color=black;
title 'First difference for xt';
proc gplot data=identify;
 plot dser4*t;
run;
*then plot the original plot again;
goptions reset=all i=join;
symbol1 color=black;
title 'Original series';
proc gplot data=identify;
 plot xt*t;
run;

*then we need to do the stationarity test;
proc arima data=identify plots(only)=series(acf pacf);
 identify var=xt(1) stationarity=(adf=(0,1));
 identify var=xt stationarity=(adf=(0,1));
run;

*then for series yt;
goptions reset=all i=join;
symbol1 color=red;
title 'First difference of yt';
proc gplot data=identify;
 plot dser5*t;
run;

*then for the original series;
goptions reset=all i=join;
symbol1 color=red;
title 'Original series for xt';
proc gplot data=identify;
 plot yt*t;
run;

*then we need to do the stationarity test;
proc arima data=identify plots(only)=series(acf pacf);
identify var=yt(1) stationarity=(adf=(0,1));
identify var=yt    stationarity=(adf=(0,1));
run;

*then for zt;
goptions reset=all i=join;
symbol1 color=red;
title 'First difference for zt';
proc gplot data=identify;
 plot dser6*t;
run;
*then for the original model;
goptions reset=all i=join;
 plot zt*t;
run;

*then we need to do stationarity test;
proc arima data=identify plots(only)=series(acf pacf);
 identify var=zt(1) stationarity=(adf=(0,1));
 identify var=zt    stationarity=(adf=(0,1));
run;
