*This is exercise 4;
proc import datafile="exercise4.csv"
out=Exe4 
dbms=csv
replace;
run;

*Question a1-ut;
goptions reset=all i=join;
symbol1 color=Red;
title1 'Time series for Ut';
proc gplot data=Exe4;
 plot ut*t;
run;

proc arima data=Exe4 plots(only)=series(acf pacf);
 identify var=ut scan esacf p=(0:4) q=(0:4);
 run;


*Question A1-vt;
 goptions reset=all i=join;
symbol1 color=Red;
title1 'Time series for Vt';
proc gplot data=Exe4;
 plot vt*t;
run;

*then we need to do the tentative tests;
proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=vt scan esacf p=(0:4) q=(0:4);
run;


*Question A1-wt;
 goptions reset=all i=join;
symbol1 color=Red;
title1 'Time series for Wt';
proc gplot data=Exe4;
 plot wt*t;
run;

proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=wt scan esacf p=(0:4) q=(0:4);
run;

*Question A1-xt;
 goptions reset=all i=join;
symbol1 color=Red;
title1 'Time series for xt';
proc gplot data=Exe4;
 plot xt*t;
run;

proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=xt scan esacf p=(0:4) q=(0:4);
run;


*Question A1-yt;
 goptions reset=all i=join;
symbol1 color=Red;
title1 'Time series for yt';
proc gplot data=Exe4;
 plot yt*t;
run;

proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=yt scan esacf p=(0:4) q=(0:4);
run;

*Question A1-zt;
 goptions reset=all i=join;
symbol1 color=Red;
title1 'Time series for zt';
proc gplot data=Exe4;
 plot zt*t;
run;

*doing the tentative test;
proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=zt scan escaf p=(0:4) q=(0:4);
run;
