*This is exercise 4;
proc import datafile="exercise4.csv"
out=Exe4 
dbms=csv
replace;
run;

*we need to get the first difference of the series;
*then based on the above answer ut has one unit root, we difference once;
proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=ut(1) nlag=6 minic p=(0:2) q=(0:2);
run;


*this is for series Vt;
proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=vt nlag=6 minic p=(0:2) q=(0:2); *this one is already statioanary with d=0 we do no need to difference it;
run;

*then now we are doing for series wt, we saw that wt is stationary and has no unit root
*we do not need to difference it;
proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=wt nlag=6 minic p=(0:2) q=(0:2);
run;

*now i am doing for xt, we see that xt has 2 unit roots meaning we need to differene twice 
to make it stationary;
proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=xt(1,1) nlag=6 minic p=(0:2) q=(0:2); *this one we difference it twice;
run;

*then we need to do for yt, and we saw that yt has no unit roots its stationary 
meaning we do not have to difference it;
proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=yt nlag=6 minic p=(0:2) q=(0:2);
run;

*we then need to do the last one which zt
we see that zt has one unit root;
proc arima data=Exe4 plots(only)=series(acf pacf);
identify var=zt(1) nlag=6 minic p=(0:2) q=(0:2);
run;
