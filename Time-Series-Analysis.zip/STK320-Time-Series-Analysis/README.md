# STK320 Time Series Analysis (2025)

Assignments and exercises for **STK320 Time Series Analysis** at the University of Pretoria,
written mainly in **SAS** (`PROC ARIMA`, data-step simulation) with some **R**.
The work covers exploring real time series, simulating stochastic processes, identifying
ARIMA models and producing forecasts.

## Contents

| Folder | Topic | What is done |
|---|---|---|
| [Assignment 1](Assignment-1_Descriptive-Analysis-and-Coloured-Noise) | Descriptive analysis and coloured noise | Time plots and correlograms of the Wolfer sunspot series and Katse Dam monthly rainfall; volatility of the rand/dollar exchange rate; simulating white, blue and red noise (SAS and R) |
| [Assignment 2](Assignment-2_MA-AR-and-Seasonal-Models) | MA, AR and seasonal models | Simulating MA(1) processes; simulating an AR(1) process around a mean and comparing it with a misspecified model; fitting a harmonic (cosine and sine) seasonal model to Katse Dam rainfall |
| [Exercise 4](Exercise-4_Unit-Roots-and-ARIMA-Identification) | Unit roots and model identification | ACF/PACF, SCAN and ESACF for six series; first differencing; selecting ARIMA orders with MINIC |
| [Exercise 5](Exercise-5_AR2-Simulation-and-Forecasting) | AR(2) simulation and forecasting | Simulating an AR(2) process, fitting it by maximum likelihood and forecasting 50 steps ahead |
| [Exercise 6](Exercise-6_AR2-and-ARMA-Model-Fitting) | Model fitting and comparison | Simulating an AR(2) series and fitting AR and ARMA(1,1) models to it |

## Data
- `wolfer.csv`: annual Wolfer sunspot numbers, 1750 to 1900
- `katsedam.csv`: monthly rainfall at Katse Dam
- `exercise4.csv`: six simulated series (ut, vt, wt, xt, yt, zt)

Assignment 1 Question 2 also uses `rand-dollar.txt`, a lecture example file that is not included here.

## How to run
- **SAS:** open a `.sas` file in SAS or SAS OnDemand for Academics, make sure the CSV is in
  the SAS working folder (or edit the `datafile=` path), and run it.
- **R:** set the working directory to the assignment folder and run the script.
  Packages used: `ggplot2`.

## Author
Tlou (Maima) Bonginkosi Fortune
