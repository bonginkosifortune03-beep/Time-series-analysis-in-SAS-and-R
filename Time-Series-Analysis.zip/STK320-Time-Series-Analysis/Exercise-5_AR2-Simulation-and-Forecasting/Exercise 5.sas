*This is the saswe code for the exercise 5;
data fit_ar2;
n=500;                   *number of obeservations that we need to simulate;
seed=13;
theta0=120;              *we get this from the equation;
phi1=0.2;                *we get this from the equation;
phi2=0.6;                *we also get this from the equation;
mu=theta0/(1-phi1-phi2); *this is theoretical mean wwe calculate;
var_at=100;              *this is the variance of the white noise term;
zt_2=mu;
zt_1=mu;
*then we do a do loop;
do t = -49 to n;   *we need to start -49 to 500;
  at=sqrt(var_at)*rannor(seed);
  zt=theta0 + phi1 * zt_1 + phi2 * zt_2 + at; *this is the given eqauations;
  if t > 0 then output;
  zt_2 = zt_1; *we need this so that we reintialise everytime the loop;
  zt_1 = zt;
end;
run;

*then we can plot it if we want to;
goptions reset=all i=join;
symbol color=red;
proc gplot data=fit_ar2;
 plot zt*t;
run;


*Question 2;
*Proc arima fitting an AR(2) model;
proc arima data=fit_ar2 plots(only)=series(acf pacf);
identify var=zt nlag=12;
estimate p=2 method=ml;
run;


*then we need to forecast here ;
proc arima data=fit_ar2 out=fit_ar2_out plots=none;
identify var=zt nlah=12 noprint;
estimate p=2 method=ml noprint;
forecast lead=50;
run;
